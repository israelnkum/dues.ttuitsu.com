<div class="col-md-8  text-left">
    <div class="d-flex m-r-20 m-l-10 hidden-md-down">
        <div class="chart-text m-r-10">
            <h5 class="m-b-0"><small>HND LEVEL 100</small></h5>
            <h4 class="m-t-0 text-info">
                500
            </h4>
        </div>
        <div class="chart-text m-r-10">
            <h5 class="m-b-0"><small>HND LEVEL 200</small></h5>
            <h4 class="m-t-0 text-info">
                500
            </h4>
        </div>
        <div class="chart-text m-r-10">
            <h5 class="m-b-0"><small>HND LEVEL 300</small></h5>
            <h4 class="m-t-0 text-info">
                500
            </h4>
        </div>
        <div class="chart-text m-r-10">
            <h5 class="m-b-0"><small>Diploma LEVEL 100</small></h5>
            <h4 class="m-t-0 text-info">
                500
            </h4>
        </div>
        <div class="chart-text m-r-10">
            <h5 class="m-b-0"><small>Diploma LEVEL 100</small></h5>
            <h4 class="m-t-0 text-info">
                500
            </h4>
        </div>
        <div class="chart-text m-r-10">
            <h5 class="m-b-0"><small>BTECH LEVEL 100</small></h5>
            <h4 class="m-t-0 text-info">
                500
            </h4>
        </div>
        <div class="chart-text m-r-10">
            <h5 class="m-b-0"><small>BTECH LEVEL 100</small></h5>
            <h4 class="m-t-0 text-info">
                500
            </h4>
        </div>
    </div>
</div>