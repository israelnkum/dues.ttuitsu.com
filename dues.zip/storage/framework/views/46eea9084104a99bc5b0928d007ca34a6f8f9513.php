<?php $__env->startSection('content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-wrapper">
        <div class="container-fluid">
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">System Preference</li>
                    </ol>
                </div>

                <div class="col-md-7 align-self-center text-right">
                    <div class="d-flex justify-content-end align-items-center">
                        <div class="chart-text m-r-10  d-none d-lg-block m-l-15">
                            <h5 class="m-b-0"><small>Preferences</small></h5>
                            <h4 class="m-t-0 text-info">

                            </h4>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->


            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success" role="alert">
                                            <h3 class="mb-0"><?php echo e(session('success')); ?></h3>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(session('update_success')): ?>
                                        <div class="alert alert-success" role="alert">
                                            <h3 class="mb-0"><?php echo e(session('update_success')); ?></h3>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(session('delete_success')): ?>
                                        <div class="alert alert-success" role="alert">
                                            <h3 class="mb-0"><?php echo e(session('delete_success')); ?></h3>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(session('error')): ?>
                                        <div class="alert alert-danger" role="alert">
                                            <h3 class="mb-0"><?php echo e(session('error')); ?></h3>
                                        </div>
                                    <?php endif; ?>


                                    <?php if(count($errors)>0): ?>
                                            <div class="alert alert-danger" role="alert">
                                                <ul>
                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo $error; ?></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>
                                </div>
                            </div>
                            <div class="container">
                                <h3 class="text-danger">Department Information</h3>
                                <div class="row">
                                    <div class="col-md-6">
                                        <form action="<?php echo e(url('/duesPreference')); ?>" class="form-horizontal form-material needs-validation" method="post" novalidate enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-row">
                                                <div class="col-md-12 mb-3">
                                                    <input type="text" name="departmentName"  placeholder="Department Name"
                                                           value="<?php echo e($depName->departmentName); ?>" required class="form-control">
                                                    <div class="invalid-feedback">
                                                        Name is required
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="col-md-4 mb-3">
                                                    <small class="text-danger">Optional</small>
                                                    <div class="custom-file">
                                                        <input type="file" class="custom-file-input" name="select_file"  id="customFile">
                                                        <label class="custom-file-label" for="customFile">Choose file</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <button class="btn btn-primary" name="upload" type="submit">
                                                <i class="fa fa-edit"></i>
                                                Update Info
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <form action="<?php echo e(route('duesPreference.store')); ?>" class="form-horizontal form-material needs-validation" method="post" novalidate enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-row">
                                                <div class="col-md-12 mb-3">
                                                    <div class="table-responsive m-t-40">
                                                        <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                                            <thead>
                                                            <tr>
                                                                <th>Class Name</th>
                                                                <th>Current Amount</th>
                                                                <th>Action</th>
                                                            </tr>
                                                            </thead>
                                                            <tfoot>
                                                            <tr>
                                                                <th>Class Name</th>
                                                                <th>Current Amount</th>
                                                                <th>Action</th>
                                                            </tr>
                                                            </tfoot>
                                                            <tbody>
                                                            <?php $__currentLoopData = $level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lvl =>$name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <?php if(count($level) ==0): ?>
                                                                        <h3 class="text-danger">Add Class ==></h3>
                                                                    <?php else: ?>
                                                                        <td><?php echo $name->name; ?></td>
                                                                        <td><input type="text" value="<?php echo e($name->amountPaying); ?>"  disabled placeholder="Current Amount" required readonly class="form-control"></td>

                                                                        <td>
                                                                            <div class="row">
                                                                                <div class="col-md-6">
                                                                                    <a role="button" href="#" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModalCenter">
                                                                                        <i class="fa fa-edit"></i>
                                                                                    </a>
                                                                                    
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    <a role="button" href="#" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteModal">
                                                                                        <i class="fa fa-window-close"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>


                                                                        </td>

                                                                    <?php endif; ?>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-md-6 text-right">
                                        <h3 class="text-danger">
                                            Add Class
                                        </h3>
                                        <form action="<?php echo e(route('levels.store')); ?>" class="form-horizontal form-material needs-validation" method="post" novalidate enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-row">
                                                <div class="col-md-4 offset-md-8 mb-3">
                                                    <input type="text" name="levelName" placeholder="Class" required class="form-control">
                                                    <div class="invalid-feedback">
                                                        Name is required
                                                    </div>
                                                </div>

                                                <div class="col-md-4 offset-md-8 mb-3">
                                                    <input type="number" name="amountPaying" placeholder="Amount" required class="form-control">
                                                    <div class="invalid-feedback">
                                                        Amount is required
                                                    </div>
                                                </div>
                                            </div>
                                            <button class="btn btn-primary" type="submit">
                                                <i class="fa fa-plus"></i> Add Class
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-4">
                                        <h3>Souvenirs</h3>
                                        <form>
                                            <ul class="list-group list-group-flush">
                                                <?php $__currentLoopData = $souvenir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="list-group-item  d-flex justify-content-between align-items-cente">
                                                        <?php echo e($item->name); ?>

                                                        <?php echo Form::open(['action'=>['SouvenirController@destroy',$item->id],'method'=>'POST']); ?>

                                                        <?php echo e(Form::hidden('_method','DELETE')); ?>

                                                        <button type="submit"  class="btn btn-danger btn-sm">
                                                            <i class="fa fa-window-close"></i>
                                                        </button>
                                                        <?php echo Form::close(); ?>


                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </form>
                                    </div>

                                    <div class="col-md-6 text-right">
                                        <h3 class="text-danger">
                                            Add Souvenirs
                                        </h3>
                                        <form action="<?php echo e(route('souvenir.store')); ?>" class="form-horizontal form-material needs-validation" method="post" novalidate enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-row">
                                                <div class="col-md-4 offset-md-8 mb-3">
                                                    <input type="text" name="souvenir" placeholder="Souvenir" required class="form-control">
                                                    <div class="invalid-feedback">
                                                        Name is required
                                                    </div>
                                                </div>
                                            </div>
                                            <button class="btn btn-primary" type="submit">
                                                <i class="fa fa-plus"></i> Add
                                            </button>
                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php if(count($level)==0): ?>

            <?php else: ?>
                <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalCenterTitle">Set New Amount</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <?php echo Form::open(['action' => ['LevelController@update',$name->id],'method'=>'POST','class'=>'form-horizontal form-material needs-validation','novalidate' ]); ?>

                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <div class="form-row">
                                    <div class="col-md-4 mb-3">
                                        <?php echo e(Form::label('newName','Name')); ?>

                                        <?php echo e(Form::text('newName',$name->name,['class'=>'form-control','placeholder'=>'Name','required'] )); ?>

                                        <div class="invalid-feedback">
                                            Name is required
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <?php echo e(Form::label('newAmtPaying','New Amount')); ?>

                                        <?php echo e(Form::text('newAmtPaying',$name->amountPaying,['class'=>'form-control','placeholder'=>'New Amount','required'] )); ?>

                                        <div class="invalid-feedback">
                                            Index Number is required
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">

                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <?php echo e(Form::hidden('_method','PUT')); ?>

                                <button type="submit" class="btn btn-primary">Save changes</button>
                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>









                <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog"  aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalCenterTitle">Confirm Delete</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <?php echo Form::open(['action'=>['LevelController@destroy',$name->id],'method'=>'POST']); ?>

                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                Do you really want to delete
                            </div>
                            <div class="modal-footer">

                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <?php echo e(Form::hidden('_method','DELETE')); ?>

                                <button type="submit" class="btn btn-primary">Delete</button>
                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>