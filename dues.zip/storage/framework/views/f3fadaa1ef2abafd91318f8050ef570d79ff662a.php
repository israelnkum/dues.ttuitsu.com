<?php $__env->startSection('content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="row page-titles">
        <div class="col-md-12 align-self-center text-right">
            <div class="d-flex justify-content-end align-items-center">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Admin(s)</a></li>
                    <li class="breadcrumb-item active">All Administrators</li>
                </ol>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">All Administrators</h4>
                    <h6 class="card-subtitle">Both Admin's and Super Admin's</h6>
                    <div class="table-responsive m-t-40">
                        <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Phone Number</th>
                                <th>User type</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Phone Number</th>
                                <th>User type</th>
                                <th>Action</th>

                            </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $allAdmin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($admin['firstName']." ".$admin['lastName']); ?></td>
                                    <td><?php echo e($admin['username']); ?></td>
                                    <td><?php echo e($admin['email']); ?></td>
                                    <td><?php echo e($admin['phoneNumber']); ?></td>
                                    <td><label class="badge badge-info">Admin</label></td>
                                    <td>
                                        <div class="row">
                                            <a href="<?php echo e(route('admin.showDetails',[$admin['id'],$admin['userType']])); ?>" class="btn btn-success mr-3 text-white">
                                                <i class="mdi mdi-face-profile "></i>
                                            </a>
                                            <?php echo Form::open(['route' => ['admin.deleteAdmin',$admin['id'],$admin['userType']],'method'=>'POST','class'=>'form-horizontal form-material']); ?>

                                            <?php echo e(Form::hidden('_method','DELETE')); ?>

                                            <button type="submit" class="btn btn-danger mr-0 text-white">
                                                <i class="mdi mdi-delete"></i>
                                            </button>
                                            <?php echo Form::close(); ?>

                                        </div>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $allSuperAdmin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($admin['firstName']." ".$admin['lastName']); ?></td>
                                    <td><?php echo e($admin['username']); ?></td>
                                    <td><?php echo e($admin['email']); ?></td>
                                    <td><?php echo e($admin['phoneNumber']); ?></td>
                                    <td><label class="badge badge-success">Super Admin</label></td>
                                    <td>
                                        <div class="row">
                                            <a href="<?php echo e(route('admin.showDetails',[$admin['id'],$admin['userType']])); ?>" class="btn btn-success mr-3 text-white">
                                                <i class="mdi mdi-face-profile "></i>
                                            </a>
                                            <?php echo Form::open(['route' => ['admin.deleteAdmin',$admin['id'],$admin['userType']],'method'=>'POST','class'=>'form-horizontal form-material']); ?>

                                            <?php echo e(Form::hidden('_method','DELETE')); ?>

                                            <button type="submit" class="btn btn-danger mr-0 text-white">
                                                <i class="mdi mdi-delete"></i>
                                            </button>
                                            <?php echo Form::close(); ?>

                                        </div>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>