<?php $__env->startSection('content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="row page-titles">
        <div class="col-md-4 align-self-center">
            <div class="d-flex ">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                    <li class="breadcrumb-item active">All Student</li>
                </ol>
            </div>
        </div>
        <div class="col-md-8  text-left">
            <div class="d-flex m-r-20 m-l-10 hidden-md-down">
                <div class="chart-text m-r-10">
                    <h5 class="m-b-0"><small>HND LEVEL 100</small></h5>
                    <h4 class="m-t-0 text-info">
                        500
                    </h4>
                </div>
                <div class="chart-text m-r-10">
                    <h5 class="m-b-0"><small>HND LEVEL 200</small></h5>
                    <h4 class="m-t-0 text-info">
                        500
                    </h4>
                </div>
                <div class="chart-text m-r-10">
                    <h5 class="m-b-0"><small>HND LEVEL 300</small></h5>
                    <h4 class="m-t-0 text-info">
                        500
                    </h4>
                </div>
                <div class="chart-text m-r-10">
                    <h5 class="m-b-0"><small>Diploma LEVEL 100</small></h5>
                    <h4 class="m-t-0 text-info">
                        500
                    </h4>
                </div>
                <div class="chart-text m-r-10">
                    <h5 class="m-b-0"><small>Diploma LEVEL 100</small></h5>
                    <h4 class="m-t-0 text-info">
                        500
                    </h4>
                </div>
                <div class="chart-text m-r-10">
                    <h5 class="m-b-0"><small>BTECH LEVEL 100</small></h5>
                    <h4 class="m-t-0 text-info">
                        500
                    </h4>
                </div>
                <div class="chart-text m-r-10">
                    <h5 class="m-b-0"><small>BTECH LEVEL 100</small></h5>
                    <h4 class="m-t-0 text-info">
                        500
                    </h4>
                </div>
            </div>

        </div>

    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Info box -->
    <!-- ============================================================== -->


    <!-- ============================================================== -->
    <!-- End Info box -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <?php if(session('success')): ?>
                                <div class="alert alert-success" role="alert">
                                    <h3 class="mb-0"><?php echo e(session('success')); ?></h3>
                                </div>
                            <?php endif; ?>

                            <?php if(session('update_success')): ?>
                                <div class="alert alert-success" role="alert">
                                    <h3 class="mb-0"><?php echo e(session('update_success')); ?></h3>
                                </div>
                            <?php endif; ?>

                            <?php if(session('delete_success')): ?>
                                <div class="alert alert-success" role="alert">
                                    <h3 class="mb-0"><?php echo e(session('delete_success')); ?></h3>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6 text-right">

                        </div>
                    </div>
                    <div class="row">
                        <?php echo Form::open(['action' => ['PaymentController@update',$student->id],'method'=>'POST','class'=>'form-horizontal form-material needs-validation','novalidate' ]); ?>

                        <div class="container">
                            <?php if($maxAmount != $student->amount_paid): ?>
                                <div class="form-row">
                                    <div class="col-md-4 mb-3">
                                        <label for="amountPaying">Amount Paying</label>
                                        <input type="number" name="amountPaying" class="form-control" placeholder="Amount Paying" required min="1" max="<?php echo e($maxAmount -$student->amount_paid); ?>">
                                        <div class="invalid-feedback">
                                            Amount is invalid
                                        </div>
                                        <input value="<?php echo e($stdLevel); ?>" type="hidden" name="stdLevel" class="form-control" required >
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php $__currentLoopData = $selectedSouvenirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $souvenir =>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item form-check">
                                            <input type="checkbox" value="<?php echo e(preg_replace('/\s+/', '',  $row)); ?>" class="form-check-input" name="<?php echo e(preg_replace('/\s+/', '',  $row)); ?>" id="<?php echo e(preg_replace('/\s+/', '',  $row)); ?>">
                                            <label class="form-check-label" for="<?php echo e(preg_replace('/\s+/', '',  $row)); ?>"><?php echo e($row); ?></label>
                                        </li>
                                    </ul>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-row">
                                <div class="col-md-12 mb-3 text-right">
                                    <a role="button" href="<?php echo e(route('student.index')); ?>" class="btn btn-danger">Cancel</a>
                                    <?php echo e(Form::hidden('_method','PUT')); ?>

                                    <button class="btn btn-primary" type="submit">Submit form</button>
                                </div>
                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>