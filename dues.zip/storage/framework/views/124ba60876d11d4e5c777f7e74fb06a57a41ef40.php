<?php $__env->startSection('content'); ?>
    <div class="row page-titles">
        <div class="col-md-12 align-self-center text-right">
            <div class="d-flex justify-content-end align-items-center">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Admin</a></li>
                    <li class="breadcrumb-item active">Update Information</li>
                </ol>
            </div>
        </div>
    </div>
    <div class="row" id="validation">
        <div class="col-12">
            <div class="card wizard-content">
                <div class="card-body">
                    <h3 class="card-title text-danger">Please update your information before you continue</h3>
                    
                    <?php echo Form::open(['action' => 'AdminController@updateSuperAdminInfo','method'=>'POST','class'=>'form-horizontal form-material validation-wizard wizard-circle']); ?>

                        <!-- Step 1 -->
                    <h6>Personal Information</h6>
                    <section>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
                                    <label for="wlocation2">Title</label>
                                    <select class="custom-select form-control required"  name="title">
                                        <option value="<?php echo e(Auth::user()->title); ?>"><?php echo e(Auth::user()->title); ?></option>
                                        <option value="Mr">Mr</option>
                                        <option value="Mrs">Mrs</option>
                                        <option value="Miss">Miss</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php echo e(Form::label('firstName','First Name')); ?>

                                    <?php echo e(Form::text('firstName',Auth::user()->firstName,['class'=>'form-control','placeholder'=>'Username here','required'] )); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php echo e(Form::label('lastName','Last Name')); ?>

                                    <?php echo e(Form::text('lastName',Auth::user()->lastName,['class'=>'form-control','placeholder'=>'Username here','required'] )); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="wdate2">Gender</label>
                                    <select class="custom-select form-control required" name="gender">
                                        <option value="<?php echo e(Auth::user()->gender); ?>"><?php echo e(Auth::user()->gender); ?></option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php echo e(Form::label('dateOfBirth','Date of Birth')); ?>

                                    <?php echo e(Form::text('dateOfBirth',Auth::user()->dateOfBirth,['class'=>'form-control date-inputmask required','placeholder'=>'Username here','required'] )); ?>

                                </div>
                        </div>
                        </div>
                    </section>

                        <!-- Step 2 -->
                        <h6>Contact Information</h6>
                    <section>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php echo e(Form::label('email','Email')); ?>

                                    <?php echo e(Form::email('email',Auth::user()->email,['class'=>'form-control ','placeholder'=>'Enter Email Address','required'] )); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php echo e(Form::label('phoneNumber','Phone Number ')); ?>

                                    <?php echo e(Form::text('phoneNumber',Auth::user()->phoneNumber,['class'=>'form-control phone-inputmask','placeholder'=>'Phone number here','required'] )); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php echo e(Form::label('homeTown','Home Town')); ?>

                                    <?php echo e(Form::text('homeTown',Auth::user()->homeTown,['class'=>'form-control ','placeholder'=>'Home Town','required'] )); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="wdate2">Region</label>
                                    <select class="custom-select form-control required" name="region" >
                                        <option value=<?php echo e(Auth::user()->region); ?>><?php echo e(Auth::user()->region); ?></option>
                                        <option value="Western">Western</option>
                                        <option value="Northern">Northern</option>
                                        <option value="Eastern">Eastern</option>
                                        <option value="Central">Central</option>
                                        <option value="Upper West">Upper West</option>
                                        <option value="Upper East">Upper East</option>
                                        <option value="Ashanti">Ashanti</option>
                                        <option value="Brong Ahafo">Brong Ahafo</option>
                                        <option value="Greater Accra">Greater Accra</option>
                                        <option value="Volter">Volter</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php echo e(Form::label('address','Address')); ?>

                                    <?php echo e(Form::text('address',Auth::user()->address,['class'=>'form-control ','placeholder'=>'Postal Address','required'] )); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php echo e(Form::label('houseNumber','House Number ')); ?>

                                    <?php echo e(Form::text('houseNumber',Auth::user()->houseNumber,['class'=>'form-control ','placeholder'=>'House Number','required'] )); ?>

                                </div>
                            </div>
                        </div>
                    </section>
                    <?php if(Auth::user()->updated==0): ?>
                        <h6>Security</h6>
                        <section>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <?php echo e(Form::label('username','Username')); ?>

                                        <?php echo e(Form::text('username',Auth::user()->username,['class'=>'form-control ','placeholder'=>'Username','required'] )); ?>

                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <?php echo e(Form::label('password','Password')); ?>

                                        <?php echo e(Form::password('password',['class'=>'form-control','placeholder'=>'Password','required'] )); ?>

                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <?php echo e(Form::label('confirmPassword','Confirm Password')); ?>

                                        <?php echo e(Form::password('confirmPassword',['class'=>'form-control ','placeholder'=>'Confirm Password','required'] )); ?>

                                    </div>
                                </div>
                            </div>
                        </section>
                    <?php else: ?>

                    <?php endif; ?>


                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>