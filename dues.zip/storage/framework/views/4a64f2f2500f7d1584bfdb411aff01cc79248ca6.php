
<header class="topbar">
    <nav class="navbar top-navbar navbar-expand-md navbar-dark">
        <!-- ============================================================== -->
        <!-- Logo -->
        <!-- ============================================================== -->
        <div class="navbar-header text-center">
            <a class="navbar-brand" href="javascript:void(0)">
                <!-- Logo icon --><b>
                    <img src="<?php echo e(asset('public/logo/logo.jpg')); ?>"  height="auto" width="45"
                         alt="<?php echo e($depName->departmentName); ?>"

                         class="light-logo text-uppercase" />
                </b>
                <!--End Logo icon -->
                <!-- Logo text --><span>
                         <!-- dark Logo text -->
                         <img src="<?php echo e(asset('public/mimg/itsu.jpeg')); ?>"  height="auto" width="45"
                              alt="<?php echo e($depName->departmentName); ?>"
                              class="dark-logo text-uppercase" />
                    <!-- Light Logo text -->
                    
                </span> </a>
        </div>
        <!-- ============================================================== -->
        <!-- End Logo -->
        <!-- ============================================================== -->
        <div class="navbar-collapse">
            <!-- ============================================================== -->
            <!-- toggle and nav items -->
            <!-- ============================================================== -->
            <ul class="navbar-nav mr-auto">
                <!-- This is  -->
                <!-- ============================================================== -->
                <!-- Search -->
                <!-- ============================================================== -->
                <li class="nav-item font-20">
                    <div class="app-search text-white d-none d-md-block d-lg-block">
                        Union Management System
                    </div>
                </li>
            </ul>
            <!-- ============================================================== -->
            <!-- User profile and search -->
            <!-- ============================================================== -->
            <ul class="navbar-nav my-lg-0">
                <!-- ============================================================== -->
                <!-- Comment -->
                <!-- ============================================================== -->
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            <!-- ============================================================== -->
                <!-- End Comment -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Messages -->
                <!-- ============================================================== -->
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            <!-- ============================================================== -->
                <!-- End Messages -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- mega menu -->
                <!-- ============================================================== -->

                <!-- ============================================================== -->
                <!-- End mega menu -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- User Profile -->
                <!-- ============================================================== -->
                <li class="nav-item dropdown u-pro">
                    <a class="nav-link dropdown-toggle waves-effect waves-dark profile-pic" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           <span class="hidden-md-down text-white">
                               <?php if(Auth::check()): ?>
                                   <?php echo e(Auth::user()->username); ?>

                                   &nbsp;
                               <?php endif; ?>
                               <i class="fa fa-angle-down"></i>
                            </span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right animated flipInY">
                        <!-- text-->
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->updated==0): ?>

                            <?php else: ?>
                                <?php if(Auth::user()->userType == 'admin'): ?>
                                    <a href="<?php echo e(route('super.admin.update')); ?>" class="dropdown-item"><i class="ti-user"></i> My Profile</a>
                                <?php elseif(Auth::user()->userType == 'user'): ?>
                                    <a href="<?php echo e(route('admin.update')); ?>" class="dropdown-item"><i class="ti-user"></i> My Profile</a>
                                <?php endif; ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    <!-- text-->
                        <!-- text-->
                        <div class="dropdown-divider"></div>
                        <!-- text-->
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->userType == 'user'): ?>
                                <a href="<?php echo e(route('user.logout')); ?>" class="dropdown-item">
                                    <i class="fa fa-power-off"></i>
                                    Logout
                                </a>

                            <?php elseif(Auth::user()->userType == 'admin'): ?>
                                <a href="<?php echo e(route('admin.logout')); ?>" class="dropdown-item">
                                    <i class="fa fa-power-off"></i>
                                    Logout
                                </a>

                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </li>
                <!-- ============================================================== -->
                <!-- End User Profile -->
                <!-- ============================================================== -->
                <li class="nav-item right-side-toggle"> <a class="nav-link  waves-effect waves-light" href="javascript:void(0)"><i class="ti-settings"></i></a></li>
            </ul>
        </div>
    </nav>
</header>

<!-- ============================================================== -->
<!-- End Topbar header -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
<?php if(Auth::check()): ?>
    <?php if(Auth::user()->updated==0): ?>

    <?php else: ?>
        <aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="user-pro"> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><img src="http://eliteadmin.themedesigner.in/demos/bt4/assets/images/users/1.jpg" alt="user-img" class="img-circle"><span class="hide-menu">Mark Jeckson</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="javascript:void(0)"><i class="ti-user"></i> My Profile</a></li>
                                <li><a href="javascript:void(0)"><i class="fa fa-power-off"></i> Logout</a></li>
                            </ul>
                        </li>
                        <li>
                            <?php if(Auth::check()): ?>
                                <?php if(Auth::user()->userType=='admin'): ?>
                                    <a class="waves-effect waves-dark" href="<?php echo e(route('admin-dashboard')); ?>">
                            <span class="hide-menu">
                                <i class="icon-speedometer"></i> Dashboard
                            </span>
                                    </a>

                                <?php else: ?>
                                    <a class="waves-effect waves-dark" href="<?php echo e(route('home')); ?>">
                            <span class="hide-menu">
                                <i class="icon-speedometer"></i> Dashboard
                            </span>
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </li>


                        <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false">
                                <i class="ti-layout-accordion-merged"></i>
                                <span class="hide-menu">Students</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="<?php echo e(route('student.index')); ?>">All Students</a></li>
                                <li><a href="<?php echo e(route("student.create")); ?>">New Students</a></li>
                                <li><a href="<?php echo e(route('studentUpload.index')); ?>">Upload Student</a></li>
                            </ul>
                        </li>

                        <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false">
                                <i class="ti ti-user"></i>
                                <span class="hide-menu">Registration</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="<?php echo e(route('register.index')); ?>">Registered Students</a></li>
                                <li><a href="<?php echo e(route("register.create")); ?>">Unregistered Students</a></li>
                            </ul>
                        </li>

                        <li> <a class="waves-effect waves-dark" href="<?php echo e(route('paymentLog.index')); ?>">
                            <span class="hide-menu">
                                <i class="icon-speedometer"></i> Dues Log
                            </span>
                            </a>
                        </li>
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->userType=="admin"): ?>
                                <li> <a class="waves-effect waves-dark" href="<?php echo e(route('duesPreference.index')); ?>">
                            <span class="hide-menu">
                                <i class="icon-speedometer"></i> Dues Preference
                            </span>
                                    </a>
                                </li>

                                <li>
                                    <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false">
                                        <i class="ti-settings"></i>
                                        <span class="hide-menu">
                                Admins
                            </span>
                                    </a>
                                    <ul aria-expanded="false" class="collapse">
                                        <li><a href="<?php echo e(route('admin.all')); ?>">All Admin</a></li>
                                        <li><a href="<?php echo e(route('admin.new')); ?>">New Admin</a></li>
                                        <li><a href="<?php echo e(route('super.admin.new')); ?>">New Super Admin</a></li>
                                    </ul>
                                </li>
                            <?php else: ?>
                            <?php endif; ?>
                        <?php endif; ?>

                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
    <?php endif; ?>
<?php endif; ?>