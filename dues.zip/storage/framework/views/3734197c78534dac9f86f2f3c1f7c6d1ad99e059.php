<?php $__env->startSection('content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="row page-titles">
        <div class="col-md-12 align-self-center text-right">
            <div class="d-flex justify-content-end align-items-center">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Admin</a></li>
                    <li class="breadcrumb-item active"><?php echo e($adminDetail['lastName']."'s Profile"); ?></li>
                </ol>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Column -->
        <div class="col-lg-12 col-xlg-9 col-md-7">
            <div class="card">
                <div class="card-body">
                        <h3 class="card-title text-danger"><?php echo e($adminDetail['firstName']." ".$adminDetail['lastName']."'s Profile"); ?></h3>
                    <?php echo Form::open(['class'=>'form-horizontal form-material']); ?>

                    <div class="form-group row m-t-20">
                        <div class="col-md-3">
                            <?php echo e(Form::label('username','Title')); ?>

                            <?php echo e(Form::text('username',$adminDetail['title'],['class'=>'form-control','placeholder'=>'Username','readonly'] )); ?>

                        </div>
                        <div class="col-md-3">
                            <?php echo e(Form::label('username','First Name')); ?>

                            <?php echo e(Form::text('username',$adminDetail['firstName'],['class'=>'form-control','placeholder'=>'Username','readonly'] )); ?>

                        </div>
                        <div class="col-md-3">
                            <?php echo e(Form::label('username','Last Name')); ?>

                            <?php echo e(Form::text('username',$adminDetail['lastName'],['class'=>'form-control','placeholder'=>'Username','readonly'] )); ?>

                        </div>
                        <div class="col-md-3">
                            <?php echo e(Form::label('username','Username')); ?>

                            <?php echo e(Form::text('username',$adminDetail['username'],['class'=>'form-control','placeholder'=>'Username','readonly'] )); ?>

                        </div>
                    </div>


                    <div class="form-group row m-t-20">
                        <div class="col-md-4">
                            <?php echo e(Form::label('username','Phone Number')); ?>

                            <?php echo e(Form::text('username',$adminDetail['phoneNumber'],['class'=>'form-control','placeholder'=>'Username','readonly'] )); ?>

                        </div>
                        <div class="col-md-4">
                            <?php echo e(Form::label('username','Date of Birth')); ?>

                            <?php echo e(Form::text('username',$adminDetail['dateOfBirth'],['class'=>'form-control','placeholder'=>'Username','readonly'] )); ?>

                        </div>
                        <div class="col-md-4">
                            <?php echo e(Form::label('username','Home Town')); ?>

                            <?php echo e(Form::text('username',$adminDetail['homeTown'],['class'=>'form-control','placeholder'=>'Username','readonly'] )); ?>

                        </div>
                    </div>

                    <div class="form-group row m-t-20">
                        <div class="col-md-4">
                            <?php echo e(Form::label('username','Gender')); ?>

                            <?php echo e(Form::text('username',$adminDetail['gender'],['class'=>'form-control','placeholder'=>'Username','readonly'] )); ?>

                        </div>
                        <div class="col-md-4">
                            <?php echo e(Form::label('username','Date of Birth')); ?>

                            <?php echo e(Form::text('username',$adminDetail['address'],['class'=>'form-control','placeholder'=>'Username','readonly'] )); ?>

                        </div>
                        <div class="col-md-4">
                            <?php echo e(Form::label('username','Email')); ?>

                            <?php echo e(Form::text('username',$adminDetail['email'],['class'=>'form-control','placeholder'=>'Username','readonly'] )); ?>

                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
        <!-- Column -->
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>